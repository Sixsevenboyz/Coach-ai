const APP_VERSION = "1.1.1";
const STORE = {
  profile: "ballform.profile.v1",
  settings: "ballform.settings.v1",
  sessions: "ballform.sessions.v1"
};
const MODEL_URLS = {
  lite: "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task",
  full: "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_full/float16/1/pose_landmarker_full.task"
};
const WASM_URL = "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@1.2.0/wasm";
const HAND_MODEL_URL = "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task";
const $ = (id) => document.getElementById(id);
const clamp = (n, min, max) => Math.max(min, Math.min(max, n));
const round = (n, digits = 1) => Number.isFinite(n) ? Number(n.toFixed(digits)) : null;
const safeParse = (value, fallback) => { try { return value ? JSON.parse(value) : fallback; } catch { return fallback; } };
const readStore = (key, fallback) => { try { return safeParse(localStorage.getItem(key), fallback); } catch { return fallback; } };

const state = {
  profile: {name:"Player",hand:"right",height:"",...readStore(STORE.profile, { name: "Player", hand: "right", height: "" })},
  settings: {quality:"lite",threshold:0.5,skeleton:true,labels:false,soundEnabled:true,soundVolume:0.75,angleMode:"3d",...readStore(STORE.settings, { quality: "lite", threshold: 0.5, skeleton: true, labels: false, soundEnabled: true, soundVolume: 0.75, angleMode: "3d" })},
  sessions: readStore(STORE.sessions, []),
  landmarker: null,
  handLandmarker: null,
  modelPromise: null,
  stream: null,
  cameraFacing: "environment",
  cameraDevices: [],
  videoMode: "camera",
  videoObjectUrl: null,
  animationFrame: null,
  lastDetectAt: 0,
  lastRenderAt: 0,
  fpsFrames: 0,
  fpsStart: performance.now(),
  fps: 0,
  latestPose: null,
  latestAngles: null,
  latestHandMetrics: [],
  lastHandDetectAt: 0,
  activeSession: null,
  sessionTimer: null,
  lastPhase: "Ready",
  phaseStableCount: 0,
  soundAudio: null,
  lastSoundNumber: null,
  soundFiles: new Set(),
  angleMode: "3d",
  soundMissingWarned: false,
  allAnglesVisible: false,
  drillFilter: "All",
  nbaSearch: "",
  nbaEra: "All",
  nbaStyle: "All",
  lastPoseSnapshot: null,
  smoothedAngles: {},
  poseFilters: null,
  poseHistory: [],
  loopToken: 0,
  videoFrameHandle: null,
  lastVideoTime: -1
};
if (!state.profile || typeof state.profile !== "object") state.profile = {name:"Player",hand:"right",height:""};
if (!state.settings || typeof state.settings !== "object") state.settings = {quality:"lite",threshold:0.5,skeleton:true,labels:false,soundEnabled:true,soundVolume:0.75,angleMode:"3d"};
if (!Array.isArray(state.sessions)) state.sessions = [];
state.angleMode = state.settings.angleMode === "2d" ? "2d" : "3d";

const LANDMARK_NAMES = [
  "Nose", "Left eye inner", "Left eye", "Left eye outer", "Right eye inner", "Right eye", "Right eye outer", "Left ear", "Right ear", "Mouth left", "Mouth right", "Left shoulder", "Right shoulder", "Left elbow", "Right elbow", "Left wrist", "Right wrist", "Left pinky", "Right pinky", "Left index", "Right index", "Left thumb", "Right thumb", "Left hip", "Right hip", "Left knee", "Right knee", "Left ankle", "Right ankle", "Left heel", "Right heel", "Left foot index", "Right foot index"
];
const HAND_BONES = [[0,1],[1,2],[2,3],[3,4],[0,5],[5,6],[6,7],[7,8],[0,9],[9,10],[10,11],[11,12],[0,13],[13,14],[14,15],[15,16],[0,17],[17,18],[18,19],[19,20],[5,9],[9,13],[13,17]];
const BONES = [
  [0,1],[1,2],[2,3],[3,7],[0,4],[4,5],[5,6],[6,8],[9,10],[11,12],
  [11,13],[13,15],[15,17],[15,19],[15,21],[17,19],[12,14],[14,16],[16,18],[16,20],[16,22],[18,20],
  [11,23],[12,24],[23,24],[23,25],[25,27],[27,29],[29,31],[27,31],[24,26],[26,28],[28,30],[30,32],[28,32]
];
const JOINT_DEFINITIONS = [
  { key: "elbow", label: "Elbow joint angle", desc: "มุมข้อศอกระหว่างต้นแขน–ปลายแขน", left: [11,13,15], right: [12,14,16] },
  { key: "shoulder", label: "Shoulder angle", desc: "มุมระหว่างลำตัวส่วนบนกับต้นแขน", left: [23,11,13], right: [24,12,14] },
  { key: "hip", label: "Hip angle", desc: "มุมสะโพกระหว่างลำตัวกับต้นขา", left: [11,23,25], right: [12,24,26] },
  { key: "knee", label: "Knee joint angle", desc: "มุมข้อเข่าระหว่างต้นขา–หน้าแข้ง", left: [23,25,27], right: [24,26,28] },
  { key: "ankle", label: "Ankle angle", desc: "มุมข้อเท้าระหว่างหน้าแข้ง–เท้า", left: [25,27,31], right: [26,28,32] },
  { key: "wrist", label: "Wrist alignment", desc: "มุมแนวปลายแขน–ข้อมือ–นิ้วชี้", left: [13,15,19], right: [14,16,20] }
];
const EXTRA_MEASUREMENTS = [
  { key: "trunkLean", label: "Trunk lean", desc: "ความเอียงลำตัวรวมจากแนวดิ่ง" },
  { key: "headTilt", label: "Head / neck tilt", desc: "ความเอียงศีรษะจากแนวดิ่ง" },
  { key: "shoulderTilt", label: "Shoulder line tilt", desc: "ความเอียงของแนวหัวไหล่จากแนวนอน" },
  { key: "hipTilt", label: "Pelvis line tilt", desc: "ความเอียงของแนวสะโพกจากแนวนอน" },
  { key: "elbowHeightRatio", label: "Elbow height ratio", desc: "ระดับข้อศอกซ้าย/ขวาเทียบช่วงสะโพก–ไหล่", leftKey:"leftElbowHeight", rightKey:"rightElbowHeight", unit:"×" },
  { key: "upperArmElevation", label: "Upper-arm elevation", desc: "แนวต้นแขนจากไหล่ถึงข้อศอกเทียบแนวดิ่ง", leftKey:"upperArmElevationLeft", rightKey:"upperArmElevationRight" },
  { key: "forearmElevation", label: "Forearm elevation", desc: "แนวปลายแขนจากข้อศอกถึงข้อมือเทียบแนวดิ่ง", leftKey:"forearmElevationLeft", rightKey:"forearmElevationRight" },
  { key: "footProgression", label: "Foot progression angle", desc: "มุมแนวส้นเท้าถึงปลายเท้าเทียบแนวนอน", leftKey:"footProgressionLeft", rightKey:"footProgressionRight" }
];

const DRILLS = [
  { id:"form-01", title:"Close-range Form Shooting", category:"Shooting", time:"8–10 min", level:"Beginner", desc:"ฝึกจังหวะยกบอล การจัดแนวแขน และ Follow-through จากระยะใกล้ โดยเน้นท่าที่ทำซ้ำได้", points:["Elbow alignment","Wrist follow-through","Balanced stance"], mode:"Form Shooting" },
  { id:"shot-02", title:"Free Throw Routine", category:"Shooting", time:"10 min", level:"All levels", desc:"สร้างรูทีนก่อนยิงลูกโทษ ฝึกจังหวะเตรียมตัว ย่อตัว และปล่อยลูกให้สม่ำเสมอ", points:["Pre-shot routine","Knee / hip","Release timing"], mode:"Free Throw" },
  { id:"shot-03", title:"Five-Spot Mid-range", category:"Shooting", time:"12–15 min", level:"Intermediate", desc:"ยิงจาก 5 จุดรอบเขตโทษและบันทึก Make / Miss แยกตามตำแหน่ง", points:["Shot map","Consistency","Foot placement"], mode:"Mid-range" },
  { id:"shot-04", title:"Three-point Mechanics", category:"Shooting", time:"15 min", level:"Intermediate", desc:"ฝึกการส่งแรงจากขาและสะโพกสู่ลำตัว แขน และข้อมือโดยไม่ฝืนมุมข้อใดข้อหนึ่ง", points:["Kinetic chain","Jump balance","Release"], mode:"3-point" },
  { id:"foot-01", title:"Base & Balance", category:"Footwork", time:"6–8 min", level:"Beginner", desc:"ฝึกฐานเท้า การลงน้ำหนัก และการทรงตัวก่อนเข้าสู่ท่ายิง", points:["Ankle","Knee","Hip balance"], mode:"Free Shoot" },
  { id:"foot-02", title:"1–2 Step into Shot", category:"Footwork", time:"8 min", level:"Intermediate", desc:"ฝึกการก้าวเท้าแบบ 1–2 และการหยุดให้สมดุลก่อนขึ้นชู้ต", points:["Foot timing","Landing","Trunk balance"], mode:"Mid-range" },
  { id:"handle-01", title:"Stationary Ball Control", category:"Ball Handling", time:"8 min", level:"Beginner", desc:"ฝึกควบคุมลูกอยู่กับที่ สลับมือ และรักษาระดับลำตัวให้มั่นคง", points:["Left / right","Low stance","Control"], mode:"Free Shoot" },
  { id:"handle-02", title:"Change of Direction", category:"Ball Handling", time:"10 min", level:"Intermediate", desc:"ฝึก Crossover, Between-the-legs และการเปลี่ยนทิศทางอย่างควบคุม", points:["Crossover","Body control","Footwork"], mode:"Off-dribble" },
  { id:"finish-01", title:"Layup Footwork", category:"Finishing", time:"10 min", level:"Beginner", desc:"ฝึกจังหวะเท้าและการขึ้นจบสกอร์ใกล้ห่วง แยกซ้ายและขวา", points:["Take-off","Knee drive","Landing"], mode:"Free Shoot" },
  { id:"finish-02", title:"One-foot / Two-foot Takeoff", category:"Finishing", time:"10 min", level:"Advanced", desc:"ฝึกเลือกจังหวะกระโดดขาเดียวหรือสองขา พร้อมรักษาสมดุลเมื่อลงพื้น", points:["Jump mechanics","Hip control","Landing"], mode:"Free Shoot" }
];

const NBA_PLAYERS = [
  {name:"George Mikan", era:"1940s–1960s", style:"set", label:"Classic set-shot", tags:["pioneer","center"]},
  {name:"Bob Pettit", era:"1940s–1960s", style:"power", label:"Classic power forward scoring", tags:["legend","forward"]},
  {name:"Sam Jones", era:"1940s–1960s", style:"quick", label:"Compact championship-era guard form", tags:["legend","guard"]},
  {name:"Nate Thurmond", era:"1940s–1960s", style:"power", label:"Classic interior big-man mechanics", tags:["legend","center"]},
  {name:"Bob Cousy", era:"1940s–1960s", style:"set", label:"Classic guard form", tags:["guard","playmaker"]},
  {name:"Bill Russell", era:"1940s–1960s", style:"power", label:"Paint-focused power", tags:["defense","center"]},
  {name:"Wilt Chamberlain", era:"1940s–1960s", style:"power", label:"Power / touch", tags:["center","dominant"]},
  {name:"Oscar Robertson", era:"1940s–1960s", style:"two", label:"Balanced high-set form", tags:["guard","all-around"]},
  {name:"Jerry West", era:"1940s–1960s", style:"quick", label:"Compact perimeter form", tags:["guard","pull-up"]},
  {name:"Elgin Baylor", era:"1940s–1960s", style:"creator", label:"Creative hang-time scorer", tags:["wing","off-balance"]},
  {name:"John Havlicek", era:"1940s–1960s", style:"rhythm", label:"Motion / rhythm shooter", tags:["wing","movement"]},
  {name:"Walt Frazier", era:"1970s–1980s", style:"two", label:"Balanced guard pull-up", tags:["guard","champion"]},
  {name:"Rick Barry", era:"1940s–1960s", style:"set", label:"Distinctive set-shot mechanics", tags:["forward","legend"]},
  {name:"George Gervin", era:"1970s–1980s", style:"rhythm", label:"Finger-roll touch / rhythm scoring", tags:["wing","scoring"]},
  {name:"Kareem Abdul-Jabbar", era:"1970s–1980s", style:"high", label:"High release point", tags:["center","skyhook"]},
  {name:"Julius Erving", era:"1970s–1980s", style:"creator", label:"Airborne finisher", tags:["wing","finishing"]},
  {name:"Moses Malone", era:"1970s–1980s", style:"power", label:"Power inside scoring", tags:["center","rebound"]},
  {name:"Dave Cowens", era:"1970s–1980s", style:"power", label:"Mobile big-man scoring", tags:["center","champion"]},
  {name:"Magic Johnson", era:"1970s–1980s", style:"set", label:"Tall guard mechanics", tags:["guard","playmaker"]},
  {name:"Larry Bird", era:"1970s–1980s", style:"high", label:"High-set / quick release", tags:["forward","touch"]},
  {name:"Kevin McHale", era:"1970s–1980s", style:"high", label:"High-post touch / high release", tags:["forward","post"]},
  {name:"Bob McAdoo", era:"1970s–1980s", style:"high", label:"High-release big-man jumper", tags:["center","scoring"]},
  {name:"Isiah Thomas", era:"1970s–1980s", style:"quick", label:"Compact guard release", tags:["guard","pull-up"]},
  {name:"Michael Jordan", era:"1990s", style:"two", label:"Two-motion mid-range", tags:["guard","fadeaway"]},
  {name:"Hakeem Olajuwon", era:"1990s", style:"creator", label:"Fluid footwork / touch", tags:["center","post"]},
  {name:"Charles Barkley", era:"1990s", style:"power", label:"Power-based release", tags:["forward","inside"]},
  {name:"Karl Malone", era:"1990s", style:"power", label:"Strong base mechanics", tags:["forward","power"]},
  {name:"John Stockton", era:"1990s", style:"quick", label:"Compact set / quick trigger", tags:["guard","efficiency"]},
  {name:"Reggie Miller", era:"1990s", style:"quick", label:"Movement / quick release", tags:["shooter","off-screen"]},
  {name:"David Robinson", era:"1990s", style:"high", label:"High release point", tags:["center","face-up"]},
  {name:"Shaquille O’Neal", era:"1990s", style:"power", label:"Power / close-range touch", tags:["center","inside"]},
  {name:"Tim Duncan", era:"2000s", style:"two", label:"Structured bank-shot form", tags:["forward","fundamentals"]},
  {name:"Allen Iverson", era:"2000s", style:"creator", label:"Off-dribble pull-up", tags:["guard","quickness"]},
  {name:"Kobe Bryant", era:"2000s", style:"two", label:"High-set / fadeaway", tags:["guard","tough-shot"]},
  {name:"Kevin Garnett", era:"2000s", style:"high", label:"High release / mid-range", tags:["forward","mid-range"]},
  {name:"Dirk Nowitzki", era:"2000s", style:"high", label:"High release / one-leg fade", tags:["forward","fadeaway"]},
  {name:"Steve Nash", era:"2000s", style:"rhythm", label:"Fluid one-motion rhythm", tags:["guard","touch"]},
  {name:"Ray Allen", era:"2000s", style:"quick", label:"Compact / repeatable release", tags:["shooter","off-screen"]},
  {name:"Dwyane Wade", era:"2000s", style:"creator", label:"Off-dribble creator", tags:["guard","mid-range"]},
  {name:"LeBron James", era:"2000s", style:"power", label:"Power / drive-based shot", tags:["forward","strength"]},
  {name:"Carmelo Anthony", era:"2000s", style:"two", label:"High-set isolation jumper", tags:["forward","mid-range"]},
  {name:"Vince Carter", era:"2000s", style:"creator", label:"Dynamic elevation / pull-up", tags:["wing","athletic"]},
  {name:"Paul Pierce", era:"2000s", style:"two", label:"Controlled step-back form", tags:["forward","isolation"]},
  {name:"Tony Parker", era:"2000s", style:"creator", label:"Driving floater / touch", tags:["guard","finishing"]},
  {name:"Chauncey Billups", era:"2000s", style:"set", label:"Balanced set-point form", tags:["guard","strength"]},
  {name:"Manu Ginobili", era:"2000s", style:"creator", label:"Unorthodox off-balance form", tags:["guard","creativity"]},
  {name:"Peja Stojaković", era:"2000s", style:"high", label:"High-arcing perimeter shot", tags:["shooter","catch-and-shoot"]},
  {name:"Stephen Curry", era:"2010s", style:"quick", label:"Quick-trigger / compact rhythm", tags:["shooter","range"]},
  {name:"Klay Thompson", era:"2010s", style:"quick", label:"Repeatable catch-and-shoot", tags:["shooter","off-screen"]},
  {name:"Kevin Durant", era:"2010s", style:"high", label:"Very high release point", tags:["wing","high-release"]},
  {name:"James Harden", era:"2010s", style:"creator", label:"Off-dribble step-back", tags:["guard","step-back"]},
  {name:"Chris Paul", era:"2010s", style:"two", label:"Controlled mid-range pull-up", tags:["guard","mid-range"]},
  {name:"Damian Lillard", era:"2010s", style:"quick", label:"Deep-range quick release", tags:["guard","range"]},
  {name:"Russell Westbrook", era:"2010s", style:"power", label:"Power-driven jump shot", tags:["guard","athletic"]},
  {name:"Kawhi Leonard", era:"2010s", style:"two", label:"Compact high-set pull-up", tags:["wing","mid-range"]},
  {name:"Giannis Antetokounmpo", era:"2010s", style:"power", label:"Power / drive-oriented finish", tags:["forward","finishing"]},
  {name:"Nikola Jokić", era:"2020s–ปัจจุบัน", style:"high", label:"High release / touch", tags:["center","touch"]},
  {name:"Luka Dončić", era:"2020s–ปัจจุบัน", style:"creator", label:"Off-dribble step-back creator", tags:["guard","step-back"]},
  {name:"Jayson Tatum", era:"2020s–ปัจจุบัน", style:"two", label:"High-set wing jumper", tags:["wing","pull-up"]},
  {name:"Devin Booker", era:"2020s–ปัจจุบัน", style:"two", label:"Smooth mid-range form", tags:["guard","mid-range"]},
  {name:"Shai Gilgeous-Alexander", era:"2020s–ปัจจุบัน", style:"creator", label:"Rhythm / off-dribble control", tags:["guard","pace"]},
  {name:"Anthony Edwards", era:"2020s–ปัจจุบัน", style:"power", label:"Explosive power-based shot", tags:["guard","athletic"]},
  {name:"Trae Young", era:"2020s–ปัจจุบัน", style:"quick", label:"Quick-trigger long range", tags:["guard","range"]},
  {name:"Tyrese Haliburton", era:"2020s–ปัจจุบัน", style:"rhythm", label:"Distinctive one-motion rhythm", tags:["guard","quick-release"]},
  {name:"Joel Embiid", era:"2020s–ปัจจุบัน", style:"two", label:"High-set big-man jumper", tags:["center","face-up"]},
  {name:"Jaylen Brown", era:"2020s–ปัจจุบัน", style:"power", label:"Power wing mechanics", tags:["wing","athletic"]},
  {name:"Donovan Mitchell", era:"2020s–ปัจจุบัน", style:"creator", label:"Explosive pull-up creator", tags:["guard","off-dribble"]},
  {name:"Ja Morant", era:"2020s–ปัจจุบัน", style:"creator", label:"Dynamic off-dribble scorer", tags:["guard","finishing"]},
  {name:"Paolo Banchero", era:"2020s–ปัจจุบัน", style:"power", label:"Power forward shot creation", tags:["forward","strength"]},
  {name:"Victor Wembanyama", era:"2020s–ปัจจุบัน", style:"high", label:"High release / tall shooting window", tags:["center","high-release"]},
  {name:"Khris Middleton", era:"2020s–ปัจจุบัน", style:"two", label:"Mid-range pull-up form", tags:["wing","mid-range"]},
  {name:"Jamal Murray", era:"2020s–ปัจจุบัน", style:"creator", label:"Off-dribble / contested pull-up", tags:["guard","shot-creation"]},
  {name:"Kyrie Irving", era:"2020s–ปัจจุบัน", style:"creator", label:"Touch / balance / off-dribble", tags:["guard","handle"]},
  {name:"De'Aaron Fox", era:"2020s–ปัจจุบัน", style:"quick", label:"Quick guard release", tags:["guard","speed"]},
  {name:"Jalen Brunson", era:"2020s–ปัจจุบัน", style:"two", label:"Compact footwork / mid-range", tags:["guard","footwork"]},
  {name:"Lauri Markkanen", era:"2020s–ปัจจุบัน", style:"high", label:"High set point for a big", tags:["forward","catch-and-shoot"]},
  {name:"Desmond Bane", era:"2020s–ปัจจุบัน", style:"quick", label:"Compact repeatable release", tags:["guard","catch-and-shoot"]},
  {name:"Tyrese Maxey", era:"2020s–ปัจจุบัน", style:"quick", label:"Fast guard trigger", tags:["guard","speed"]},
  {name:"Pete Maravich", era:"1970s–1980s", style:"creator", label:"Creative guard shooting", tags:["guard","skill"]},
  {name:"Dominique Wilkins", era:"1970s–1980s", style:"power", label:"Power wing scoring", tags:["wing","athletic"]},
  {name:"Patrick Ewing", era:"1990s", style:"high", label:"High-release big-man jumper", tags:["center","mid-range"]},
  {name:"Gary Payton", era:"1990s", style:"creator", label:"Guard pull-up / mid-range", tags:["guard","defense"]},
  {name:"Jason Kidd", era:"2000s", style:"set", label:"Set-point guard jumper", tags:["guard","playmaker"]},
  {name:"Yao Ming", era:"2000s", style:"high", label:"High release / touch", tags:["center","post"]},
  {name:"Steve Kerr", era:"1990s", style:"quick", label:"Compact catch-and-shoot", tags:["shooter","quick-release"]},
  {name:"Kyle Korver", era:"2010s", style:"quick", label:"Repeatable off-screen release", tags:["shooter","movement"]},
  {name:"Mark Price", era:"1990s", style:"quick", label:"Quick guard release", tags:["guard","shooter"]},
  {name:"Dražen Petrović", era:"1990s", style:"quick", label:"High-volume perimeter shooting", tags:["guard","shooter"]},
  {name:"Grant Hill", era:"1990s", style:"creator", label:"Wing pull-up / transition", tags:["wing","all-around"]},
  {name:"Jason Williams", era:"2000s", style:"creator", label:"Creative guard touch", tags:["guard","playmaking"]},
  {name:"Amar'e Stoudemire", era:"2000s", style:"power", label:"Explosive interior finish", tags:["forward","finishing"]},
  {name:"Dwight Howard", era:"2000s", style:"power", label:"Power interior scoring", tags:["center","inside"]},
  {name:"Blake Griffin", era:"2010s", style:"power", label:"Explosive power finish", tags:["forward","athletic"]},
  {name:"Paul George", era:"2010s", style:"two", label:"High-set wing jumper", tags:["wing","pull-up"]},
  {name:"Kemba Walker", era:"2010s", style:"creator", label:"Off-dribble step-back", tags:["guard","pull-up"]},
  {name:"Brandon Ingram", era:"2020s–ปัจจุบัน", style:"high", label:"High release / mid-range", tags:["wing","length"]},
  {name:"Cade Cunningham", era:"2020s–ปัจจุบัน", style:"two", label:"Tall guard pull-up form", tags:["guard","mid-range"]},
  {name:"Cooper Flagg", era:"2020s–ปัจจุบัน", style:"creator", label:"Modern versatile wing scorer", tags:["forward","versatile"]},
  {name:"Franz Wagner", era:"2020s–ปัจจุบัน", style:"two", label:"Wing shot creation", tags:["wing","versatile"]},
  {name:"Chet Holmgren", era:"2020s–ปัจจุบัน", style:"high", label:"High release / perimeter big", tags:["center","stretch"]}
];

const STYLE_ARCHETYPES = {
  quick: {label:"Quick-trigger / compact", description:"รูปแบบการปล่อยบอลรวดเร็วและจังหวะกะทัดรัด", target:{elbow:145,shoulder:72,knee:125,hip:145,trunkLean:7,wrist:155}},
  high: {label:"High release / high window", description:"จุดปล่อยสูงและแนวแขนยกสูง", target:{elbow:135,shoulder:92,knee:120,hip:140,trunkLean:5,wrist:150}},
  two: {label:"Two-motion / high set point", description:"ยกบอลขึ้นจุดพักก่อนเหยียดแขนปล่อย", target:{elbow:105,shoulder:88,knee:125,hip:143,trunkLean:8,wrist:145}},
  rhythm: {label:"One-motion / rhythm", description:"การส่งแรงต่อเนื่องจากขาและลำตัวสู่แขน", target:{elbow:155,shoulder:76,knee:112,hip:134,trunkLean:6,wrist:160}},
  power: {label:"Power / drive-based", description:"รูปแบบใช้ฐานล่างและแรงส่งของร่างกาย", target:{elbow:125,shoulder:70,knee:115,hip:137,trunkLean:12,wrist:145}},
  creator: {label:"Off-dribble creator", description:"รูปแบบการยิงจากการสร้างจังหวะและการเคลื่อนที่", target:{elbow:130,shoulder:80,knee:120,hip:138,trunkLean:14,wrist:150}},
  set: {label:"Balanced set-shot", description:"รูปแบบตั้งฐานและจัดท่าก่อนเริ่มปล่อยบอล", target:{elbow:120,shoulder:80,knee:140,hip:150,trunkLean:4,wrist:150}}
};

function persist() {
  try {
    localStorage.setItem(STORE.profile, JSON.stringify(state.profile));
    localStorage.setItem(STORE.settings, JSON.stringify(state.settings));
    localStorage.setItem(STORE.sessions, JSON.stringify(state.sessions));
  } catch (error) {
    console.warn("Local storage save failed", error);
    toast("พื้นที่จัดเก็บเต็มหรือถูกปิดใช้งาน ข้อมูลล่าสุดอาจยังไม่ถูกบันทึก", "error");
  }
}
function toast(message, type = "") {
  const el = document.createElement("div");
  el.className = `toast ${type}`;
  el.textContent = message;
  $("toastRegion").append(el);
  window.setTimeout(() => el.remove(), 3800);
}
function showModal(title, body, actions = [], icon = "◎") {
  $("modalTitle").textContent = title;
  $("modalBody").innerHTML = body;
  $("modalIcon").textContent = icon;
  const wrap = $("modalActions");
  wrap.replaceChildren();
  actions.forEach(action => {
    const button = document.createElement("button");
    button.className = action.className || "outline-button";
    button.textContent = action.label;
    button.addEventListener("click", () => { closeModal(); action.onClick?.(); });
    wrap.append(button);
  });
  $("modalBackdrop").hidden = false;
}
function closeModal() { $("modalBackdrop").hidden = true; }
function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;", "'":"&#39;"}[c]));
}
function fmtDate(value) {
  const date = new Date(value);
  return new Intl.DateTimeFormat("th-TH", { dateStyle:"medium", timeStyle:"short" }).format(date);
}
function fmtDuration(ms) {
  const total = Math.max(0, Math.floor(ms / 1000));
  return `${String(Math.floor(total / 60)).padStart(2,"0")}:${String(total % 60).padStart(2,"0")}`;
}
function getSessionTotals(sessions = state.sessions) {
  const attempts = sessions.reduce((sum, s) => sum + (s.shots?.length || 0), 0);
  const makes = sessions.reduce((sum, s) => sum + (s.shots || []).filter(x => x.made).length, 0);
  return { attempts, makes, misses:attempts-makes, accuracy:attempts ? makes / attempts * 100 : null };
}

function setView(view) {
  const titles = {dashboard:"ภาพรวม",studio:"Live Shooting Lab",analysis:"วิเคราะห์ท่าทาง",workouts:"โปรแกรมฝึก",nba:"NBA Style Lab",history:"ประวัติการฝึก",sounds:"ระบบเสียง",settings:"ตั้งค่าระบบ"};
  document.querySelectorAll(".view").forEach(section => section.classList.toggle("active", section.id === `view-${view}`));
  document.querySelectorAll(".nav-item").forEach(button => button.classList.toggle("active", button.dataset.view === view));
  $("pageTitle").textContent = titles[view] || "BallForm AI";
  $("sidebar").classList.remove("open");
  if (view === "dashboard") renderDashboard();
  if (view === "history") renderHistory();
  if (view === "nba") renderPlayers();
  if (view === "sounds") renderSounds();
  if (view === "settings") populateSettings();
}

function getVideoAspect() {
  const video = $("cameraVideo");
  return video && video.videoWidth && video.videoHeight ? video.videoWidth / video.videoHeight : 1;
}
class OneEuro {
  constructor(minCutoff = 1.2, beta = 15, dCutoff = 1) { this.minCutoff = minCutoff; this.beta = beta; this.dCutoff = dCutoff; this.x = null; this.dx = 0; this.t = null; }
  static alpha(cutoff, dt) { const tau = 1 / (2 * Math.PI * cutoff); return 1 / (1 + tau / dt); }
  filter(v, tMs) {
    if (!Number.isFinite(v)) return v;
    if (this.t == null || tMs - this.t > 500 || tMs <= this.t) { this.x = v; this.dx = 0; this.t = tMs; return v; }
    const dt = (tMs - this.t) / 1000;
    const dxRaw = (v - this.x) / dt;
    this.dx += OneEuro.alpha(this.dCutoff, dt) * (dxRaw - this.dx);
    const cutoff = this.minCutoff + this.beta * Math.abs(this.dx);
    this.x += OneEuro.alpha(cutoff, dt) * (v - this.x);
    this.t = tMs;
    return this.x;
  }
}
function filterLandmarks(list, kind, tMs) {
  if (!list) return list;
  if (!state.poseFilters) state.poseFilters = { image: [], world: [] };
  const bank = state.poseFilters[kind];
  return list.map((p, i) => {
    if (!bank[i]) bank[i] = { x: new OneEuro(), y: new OneEuro(), z: new OneEuro() };
    const f = bank[i];
    return { ...p, x: f.x.filter(p.x, tMs), y: f.y.filter(p.y, tMs), z: f.z.filter(p.z ?? 0, tMs) };
  });
}
function resetPoseTracking() {
  state.poseFilters = null;
  state.poseHistory = [];
  state.smoothedAngles = {};
  state.lastVideoTime = -1;
}
function setTrackingOverlay(active) {
  const stage = $("cameraStage");
  if (stage) stage.classList.toggle("tracking-active", !!active);
  document.querySelectorAll(".camera-overlay, #startCameraBtn").forEach(el => {
    el.style.display = active ? "none" : "";
    el.style.visibility = active ? "hidden" : "visible";
  });
  const ph = $("cameraPlaceholder");
  if (ph) { ph.style.display = active ? "none" : ""; ph.style.visibility = active ? "hidden" : "visible"; ph.hidden = !!active; }
}
function cancelPoseLoop() {
  state.loopToken++;
  if (state.animationFrame) cancelAnimationFrame(state.animationFrame);
  state.animationFrame = null;
  const video = $("cameraVideo");
  if (state.videoFrameHandle != null && video?.cancelVideoFrameCallback) video.cancelVideoFrameCallback(state.videoFrameHandle);
  state.videoFrameHandle = null;
}

function vectorAngle(a, b, c, mode) {
  if (!a || !b || !c) return null;
  const dimensions = mode === "3d" ? ["x","y","z"] : ["x","y"];
  const v1 = dimensions.map(k => a[k] - b[k]);
  const v2 = dimensions.map(k => c[k] - b[k]);
  const dot = v1.reduce((sum, v, i) => sum + v * v2[i], 0);
  const mag1 = Math.sqrt(v1.reduce((sum, v) => sum + v*v, 0));
  const mag2 = Math.sqrt(v2.reduce((sum, v) => sum + v*v, 0));
  if (mag1 < 1e-7 || mag2 < 1e-7) return null;
  return Math.acos(clamp(dot / (mag1 * mag2), -1, 1)) * 180 / Math.PI;
}
function pointFor(list, index, mode) {
  const p = list?.[index];
  if (!p) return null;
  if (mode === "3d") return {x:p.x, y:p.y, z:p.z ?? 0, visibility:p.visibility ?? p.presence ?? 0};
  return {x:p.x * getVideoAspect(), y:p.y, z:0, visibility:p.visibility ?? p.presence ?? 0};
}
function averagePoints(list, indices, mode) {
  const ps = indices.map(i => pointFor(list, i, mode)).filter(Boolean);
  if (ps.length !== indices.length) return null;
  return {x:ps.reduce((s,p)=>s+p.x,0)/ps.length,y:ps.reduce((s,p)=>s+p.y,0)/ps.length,z:ps.reduce((s,p)=>s+p.z,0)/ps.length,visibility:Math.min(...ps.map(p=>p.visibility))};
}
function lineTilt(a, b, mode) {
  if (!a || !b) return null;
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  return Math.atan2(Math.abs(dy), Math.abs(dx)) * 180 / Math.PI;
}
function footProgressionAngle(heel, toe, mode) {
  if (!heel || !toe) return null;
  const dx = toe.x - heel.x;
  const groundDepth = mode === "3d" ? (toe.z ?? 0) - (heel.z ?? 0) : toe.y - heel.y;
  if (Math.hypot(dx, groundDepth) < 1e-7) return null;
  return Math.atan2(Math.abs(groundDepth), Math.abs(dx)) * 180 / Math.PI;
}
function fromVertical(a, b, mode) {
  if (!a || !b) return null;
  const v = [b.x-a.x, b.y-a.y, mode === "3d" ? b.z-a.z : 0];
  const len = Math.sqrt(v.reduce((s,x)=>s+x*x,0));
  if (len < 1e-7) return null;
  return Math.acos(clamp(Math.abs(v[1]) / len, -1, 1)) * 180 / Math.PI;
}
function ratioHeight(hip, shoulder, elbow) {
  if (!hip || !shoulder || !elbow) return null;
  const span = Math.abs(hip.y - shoulder.y);
  if (span < 1e-6) return null;
  return Math.abs((hip.y - elbow.y) / span);
}
function buildMeasurements(image, world, mode = "3d") {
  const source = mode === "3d" ? world : image;
  if (!source || source.length < 33) return null;
  const measures = {};
  JOINT_DEFINITIONS.forEach(def => {
    const l = def.left.map(i => pointFor(source,i,mode));
    const r = def.right.map(i => pointFor(source,i,mode));
    const confL = Math.min(...def.left.map(i=>image[i]?.visibility ?? image[i]?.presence ?? 0));
    const confR = Math.min(...def.right.map(i=>image[i]?.visibility ?? image[i]?.presence ?? 0));
    measures[`${def.key}Left`] = confL >= state.settings.threshold ? vectorAngle(l[0],l[1],l[2],mode) : null;
    measures[`${def.key}Right`] = confR >= state.settings.threshold ? vectorAngle(r[0],r[1],r[2],mode) : null;
    measures[`${def.key}ConfLeft`] = confL;
    measures[`${def.key}ConfRight`] = confR;
  });
  const shoulders = averagePoints(source,[11,12],mode);
  const hips = averagePoints(source,[23,24],mode);
  const nose = pointFor(source,0,mode);
  measures.trunkLean = fromVertical(hips,shoulders,mode);
  measures.headTilt = fromVertical(shoulders,nose,mode);
  measures.shoulderTilt = lineTilt(pointFor(source,11,mode),pointFor(source,12,mode),mode);
  measures.hipTilt = lineTilt(pointFor(source,23,mode),pointFor(source,24,mode),mode);
  measures.leftElbowHeight = ratioHeight(pointFor(source,23,mode),pointFor(source,11,mode),pointFor(source,13,mode));
  measures.rightElbowHeight = ratioHeight(pointFor(source,24,mode),pointFor(source,12,mode),pointFor(source,14,mode));
  measures.upperArmElevationLeft = fromVertical(pointFor(source,11,mode),pointFor(source,13,mode),mode);
  measures.upperArmElevationRight = fromVertical(pointFor(source,12,mode),pointFor(source,14,mode),mode);
  measures.forearmElevationLeft = fromVertical(pointFor(source,13,mode),pointFor(source,15,mode),mode);
  measures.forearmElevationRight = fromVertical(pointFor(source,14,mode),pointFor(source,16,mode),mode);
  measures.footProgressionLeft = footProgressionAngle(pointFor(source,29,mode),pointFor(source,31,mode),mode);
  measures.footProgressionRight = footProgressionAngle(pointFor(source,30,mode),pointFor(source,32,mode),mode);
  measures.mode = mode;
  measures.timestamp = Date.now();
  return measures;
}
function buildHandMetrics(result) {
  const hands = result?.landmarks || [];
  return hands.map((points, handIndex) => {
    const world = result.worldLandmarks?.[handIndex] || points;
    const category = result.handedness?.[handIndex]?.[0];
    const score = category?.score ?? null;
    const handedness = category?.categoryName || `Hand ${handIndex + 1}`;
    const angle = (a,b,c) => vectorAngle(world[a],world[b],world[c],"3d");
    const rows = [
      {finger:"Thumb",joint:"CMC",value:angle(0,1,2)},
      {finger:"Thumb",joint:"MCP",value:angle(1,2,3)},
      {finger:"Thumb",joint:"IP",value:angle(2,3,4)},
      {finger:"Index",joint:"MCP",value:angle(0,5,6)},
      {finger:"Index",joint:"PIP",value:angle(5,6,7)},
      {finger:"Index",joint:"DIP",value:angle(6,7,8)},
      {finger:"Middle",joint:"MCP",value:angle(0,9,10)},
      {finger:"Middle",joint:"PIP",value:angle(9,10,11)},
      {finger:"Middle",joint:"DIP",value:angle(10,11,12)},
      {finger:"Ring",joint:"MCP",value:angle(0,13,14)},
      {finger:"Ring",joint:"PIP",value:angle(13,14,15)},
      {finger:"Ring",joint:"DIP",value:angle(14,15,16)},
      {finger:"Pinky",joint:"MCP",value:angle(0,17,18)},
      {finger:"Pinky",joint:"PIP",value:angle(17,18,19)},
      {finger:"Pinky",joint:"DIP",value:angle(18,19,20)}
    ];
    return {handedness,score,rows,landmarks:points,worldLandmarks:world};
  });
}
function measurementRows(measures) {
  if (!measures) return [];
  const rows = [];
  JOINT_DEFINITIONS.forEach(def => rows.push({key:def.key,label:def.label,desc:def.desc,left:measures[`${def.key}Left`],right:measures[`${def.key}Right`],leftConf:measures[`${def.key}ConfLeft`],rightConf:measures[`${def.key}ConfRight`],unit:"°"}));
  EXTRA_MEASUREMENTS.forEach(def => rows.push({key:def.key,label:def.label,desc:def.desc,left:measures[def.leftKey||def.key],right:def.rightKey?measures[def.rightKey]:null,leftConf:null,rightConf:null,unit:def.unit || (def.key.toLowerCase().includes("ratio") ? "×" : "°")}));
  return rows;
}
function currentHandMeasurements(measures) {
  const side = state.profile.hand === "left" ? "Left" : "Right";
  return {
    elbow: measures?.[`elbow${side}`],
    shoulder: measures?.[`shoulder${side}`],
    hip: measures?.[`hip${side}`],
    knee: measures?.[`knee${side}`],
    ankle: measures?.[`ankle${side}`],
    wrist: measures?.[`wrist${side}`],
    trunkLean: measures?.trunkLean
  };
}
function qualityScore(image) {
  if (!image?.length) return null;
  const relevant = [0,11,12,13,14,15,16,23,24,25,26,27,28,31,32].map(i => image[i]?.visibility ?? 0);
  const visible = relevant.filter(v => v >= state.settings.threshold).length;
  return Math.round(visible / relevant.length * 100);
}
function currentPhase(image, measures) {
  if (!image || !measures) return "Ready";
  const handSide = state.profile.hand === "left" ? 15 : 16;
  const shoulderSide = state.profile.hand === "left" ? 11 : 12;
  const wrist = image[handSide], shoulder = image[shoulderSide];
  const wristRaised = wrist && shoulder && wrist.y < shoulder.y - 0.035;
  const handAboveHead = wrist && image[0] && wrist.y < image[0].y + 0.045;
  const elbow = measures[`elbow${state.profile.hand === "left" ? "Left" : "Right"}`];
  const knee = measures[`knee${state.profile.hand === "left" ? "Left" : "Right"}`];
  const kneeLoaded = Number.isFinite(knee) && knee < 135;
  if (wristRaised && Number.isFinite(elbow) && elbow > 150) return "Follow-through";
  if (wristRaised && handAboveHead && Number.isFinite(elbow) && elbow > 120) return "Release";
  if (wristRaised && Number.isFinite(elbow) && elbow <= 150) return "Set point";
  if (kneeLoaded) return "Load";
  return "Ready";
}
function updatePhaseUI(phase) {
  const labelMap = {"Ready":"READY","Load":"LOAD","Set point":"SET POINT","Release":"RELEASE","Follow-through":"FOLLOW THROUGH"};
  $("phaseLabel").textContent = `PHASE: ${labelMap[phase] || phase.toUpperCase()}`;
  const order = ["Ready","Load","Set point","Release","Follow-through"];
  document.querySelectorAll(".phase-item").forEach((item,i) => item.classList.toggle("active",order[i]===phase));
}
function generateFeedback(image, measures) {
  if (!image || !measures) return ["ยังไม่พบโครงกระดูกที่ตรวจจับได้ครบเพียงพอ"];
  const notes = [];
  const quality = qualityScore(image);
  if (quality < 65) notes.push("จุดร่างกายที่ใช้วิเคราะห์ยังเห็นไม่ครบ ลองถอยกล้องและให้เห็นศีรษะถึงเท้า");
  const side = state.profile.hand === "left" ? "Left" : "Right";
  const elbow = measures[`elbow${side}`];
  const shoulder = measures[`shoulder${side}`];
  const knee = measures[`knee${side}`];
  const wrist = measures[`wrist${side}`];
  if (Number.isFinite(elbow)) notes.push(`มุมข้อศอกข้างยิง ${round(elbow)}° — ใช้ค่านี้เปรียบเทียบระหว่างเซสชันด้วยมุมกล้องเดิม`);
  if (Number.isFinite(shoulder)) notes.push(`มุมหัวไหล่ข้างยิง ${round(shoulder)}° — ตรวจสอบแนวต้นแขนและลำตัวในเฟรม Set point`);
  if (Number.isFinite(knee)) notes.push(`มุมเข่าข้างยิง ${round(knee)}° — บันทึกช่วงย่อและช่วงเหยียดเพื่อดูรูปแบบการส่งแรง`);
  if (Number.isFinite(wrist)) notes.push(`แนวข้อมือข้างยิง ${round(wrist)}° — กล้อง 2D อาจมีผลจากการบังและมุมมองด้านข้าง`);
  if (Number.isFinite(measures.trunkLean) && measures.trunkLean > 15) notes.push(`ลำตัวเอียงจากแนวดิ่งประมาณ ${round(measures.trunkLean)}° ในเฟรมนี้`);
  if (Number.isFinite(measures.elbowLeft) && Number.isFinite(measures.elbowRight) && Math.abs(measures.elbowLeft-measures.elbowRight)>22) notes.push("มุมข้อศอกสองข้างต่างกันมาก ตรวจสอบว่ามือข้างไม่ยิงกำลังบังหรืออยู่คนละระนาบกล้อง");
  if (!notes.length) notes.push("ระบบติดตามได้แล้ว ขยับเข้าสู่ท่ายิงช้า ๆ เพื่อบันทึกการเปลี่ยนแปลงของมุมข้อต่อ");
  return notes.slice(0,5);
}
function drawPose(image, hands = state.latestHandMetrics) {
  const canvas = $("poseCanvas");
  const video = $("cameraVideo");
  if (!canvas || !video.videoWidth || !video.videoHeight) return;
  const ctx = canvas.getContext("2d");
  if (canvas.width !== video.videoWidth || canvas.height !== video.videoHeight) { canvas.width=video.videoWidth; canvas.height=video.videoHeight; }
  ctx.clearRect(0,0,canvas.width,canvas.height);
  if (!state.settings.skeleton || !image) return;
  ctx.lineWidth = Math.max(2,canvas.width/430);
  ctx.lineCap = "round";
  ctx.strokeStyle = "rgba(135,205,255,.9)";
  BONES.forEach(([a,b]) => {
    const p=image[a],q=image[b];
    if (!p||!q||(p.visibility??0)<state.settings.threshold||(q.visibility??0)<state.settings.threshold) return;
    ctx.beginPath();ctx.moveTo(p.x*canvas.width,p.y*canvas.height);ctx.lineTo(q.x*canvas.width,q.y*canvas.height);ctx.stroke();
  });
  image.forEach((p,i) => {
    if (!p || (p.visibility??0)<state.settings.threshold) return;
    const x=p.x*canvas.width,y=p.y*canvas.height;
    ctx.beginPath();ctx.fillStyle=[11,12,13,14,15,16,23,24,25,26,27,28].includes(i)?"#d8efff":"#77bff2";ctx.arc(x,y,Math.max(2.5,canvas.width/290),0,Math.PI*2);ctx.fill();
    if (state.settings.labels && [0,11,12,13,14,15,16,23,24,25,26,27,28].includes(i)) {ctx.fillStyle="#eaf7ff";ctx.font=`${Math.max(9,canvas.width/90)}px Inter`;ctx.fillText(String(i),x+5,y-5);}
  });
  (hands||[]).forEach(hand=>{
    const points=hand.landmarks||[];
    ctx.strokeStyle="rgba(173,225,255,.96)";ctx.lineWidth=Math.max(1.5,canvas.width/520);
    HAND_BONES.forEach(([a,b])=>{const p=points[a],q=points[b];if(!p||!q)return;ctx.beginPath();ctx.moveTo(p.x*canvas.width,p.y*canvas.height);ctx.lineTo(q.x*canvas.width,q.y*canvas.height);ctx.stroke();});
    points.forEach(p=>{ctx.beginPath();ctx.fillStyle="#d7efff";ctx.arc(p.x*canvas.width,p.y*canvas.height,Math.max(1.8,canvas.width/470),0,Math.PI*2);ctx.fill();});
  });
}
function updateQuickAngles(measures) {
  const side = state.profile.hand === "left" ? "Left" : "Right";
  const keys = [
    ["Elbow",measures?.[`elbow${side}`]],["Shoulder",measures?.[`shoulder${side}`]],["Knee",measures?.[`knee${side}`]],["Wrist",measures?.[`wrist${side}`]]
  ];
  $("liveAngleQuick").innerHTML = keys.map(([name,value]) => `<div class="angle-mini"><span>${name.toUpperCase()} · ${state.profile.hand.toUpperCase()}</span><b>${Number.isFinite(value)?`${round(value)}°`:"—"}</b><small>${state.angleMode.toUpperCase()} estimate</small></div>`).join("");
}
function updateLiveAngleTable(measures) {
  $("liveAngleTable").innerHTML = measurementRows(measures).map(row => `<tr><td>${escapeHTML(row.label)}</td><td>${Number.isFinite(row.left)?`${round(row.left)}${row.unit}`:"—"}</td><td>${Number.isFinite(row.right)?`${round(row.right)}${row.unit}`:"—"}</td><td>${row.leftConf!=null?`${Math.round(row.leftConf*100)}% / ${Math.round((row.rightConf||0)*100)}%`:"—"}</td></tr>`).join("");
}
function updateAnalysis(measures, image) {
  if (!measures) return;
  const side = state.profile.hand === "left" ? "Left" : "Right";
  const q = qualityScore(image);
  $("analysisSource").textContent = "LIVE SNAPSHOT";
  $("formScore").textContent = `${q ?? "—"}`;
  $("formScoreTitle").textContent = q >= 80 ? "ตรวจจับร่างกายได้ดี" : q >= 60 ? "ตรวจจับได้บางส่วน" : "ควรปรับตำแหน่งกล้อง";
  $("formScoreDesc").textContent = "คะแนนนี้วัดความครบถ้วนของ landmark ที่มองเห็น ไม่ใช่คะแนนความถูกต้องของท่าชู้ต";
  $("formScoreRing").style.background = `conic-gradient(var(--blue) ${(q||0)*3.6}deg,#283646 0deg)`;
  $("formScoreTags").innerHTML = ["Elbow","Shoulder","Knee","Wrist"].map(x=>`<span>${x}</span>`).join("");
  $("fullAngleTable").innerHTML = measurementRows(measures).map(row=>`<tr><td>${escapeHTML(row.label)}</td><td>${Number.isFinite(row.left)?`${round(row.left)}${row.unit}`:"—"}</td><td>${Number.isFinite(row.right)?`${round(row.right)}${row.unit}`:"—"}</td><td>${row.leftConf!=null?`${Math.round(row.leftConf*100)}% / ${Math.round((row.rightConf||0)*100)}%`:"derived"}</td><td>${escapeHTML(row.desc)}</td></tr>`).join("");
  const list = state.angleMode === "3d" ? state.latestPose?.world : state.latestPose?.image;
  $("landmarkTable").innerHTML = list?.map((p,i)=>{const confidence=image?.[i]?.visibility??image?.[i]?.presence??0;return `<tr><td>${String(i).padStart(2,"0")} · ${escapeHTML(LANDMARK_NAMES[i]||"Landmark")}</td><td>${round(p.x,3)}</td><td>${round(p.y,3)}</td><td>${round(p.z??0,3)}</td><td>${Math.round(confidence*100)}%</td></tr>`}).join("") || `<tr><td colspan="5" class="table-empty">ไม่พบข้อมูล</td></tr>`;
}
function updateHandAngleTable() {
  const rows = state.latestHandMetrics.flatMap(hand => hand.rows.map(row => ({...row,hand:hand.handedness,score:hand.score})));
  $("handAngleTable").innerHTML = rows.length ? rows.map(row=>`<tr><td>${escapeHTML(row.hand)}</td><td>${escapeHTML(row.finger)}</td><td>${escapeHTML(row.joint)}</td><td>${Number.isFinite(row.value)?`${round(row.value)}°`:"—"}</td><td>${row.score!=null?`${Math.round(row.score*100)}%`:"—"}</td></tr>`).join("") : '<tr><td colspan="5" class="table-empty">ยังไม่พบมือในภาพ หรือ Hand Landmarker ยังไม่พร้อม</td></tr>';
}
function updatePoseUI(image, world, measures, phase) {
  updateQuickAngles(measures);
  updateLiveAngleTable(measures);
  updateAnalysis(measures,image);
  updateHandAngleTable();
  updatePhaseUI(phase);
  $("confidenceLabel").textContent = `CONFIDENCE: ${qualityScore(image)}%`;
  $("liveFeedback").innerHTML = generateFeedback(image,measures).map(text=>`<div class="feedback-item"><span class="feedback-mark">↗</span><span>${escapeHTML(text)}</span></div>`).join("");
  if (state.activeSession) state.activeSession.lastSnapshot = makeSnapshot(image,world,measures,phase);
}
function makeSnapshot(image, world, measures, phase) {
  return {
    phase,
    angles: Object.fromEntries(Object.entries(measures||{}).filter(([k,v])=>k!=="timestamp"&&typeof v==="number"&&Number.isFinite(v)).map(([k,v])=>[k,round(v,2)])),
    quality: qualityScore(image),
    landmarks: image?.map((p,i)=>({name:LANDMARK_NAMES[i],x:round(p.x,4),y:round(p.y,4),z:round(p.z??0,4),visibility:round(p.visibility??p.presence??0,3)})) || [],
    hands: (state.latestHandMetrics||[]).map(hand=>({handedness:hand.handedness,score:round(hand.score??0,3),angles:hand.rows.map(row=>({finger:row.finger,joint:row.joint,angle:round(row.value,2)}))}))
  };
}

async function ensureLandmarker() {
  if (state.landmarker) return state.landmarker;
  if (state.modelPromise) return state.modelPromise;
  state.modelPromise = (async () => {
    $("systemStatus").textContent = "LOADING POSE MODEL";
    $("poseStateTag").textContent = "LOADING BODY + HAND MODELS";
    const { FilesetResolver, PoseLandmarker, HandLandmarker } = await import("https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@1.2.0/+esm");
    const vision = await FilesetResolver.forVisionTasks(WASM_URL);
    const model = MODEL_URLS[state.settings.quality] || MODEL_URLS.lite;
    
    // Increased detection confidence to 0.65 to improve accuracy
    const landmarker = await PoseLandmarker.createFromOptions(vision, {
      baseOptions: { modelAssetPath:model, delegate:"GPU" },
      runningMode:"VIDEO", numPoses:1,
      minPoseDetectionConfidence:0.65,minPosePresenceConfidence:0.65,minTrackingConfidence:0.65,
      outputSegmentationMasks:false
    }).catch(async (gpuError) => {
      console.warn("Pose GPU delegate failed; retrying CPU", gpuError);
      return PoseLandmarker.createFromOptions(vision, {
        baseOptions:{modelAssetPath:model,delegate:"CPU"},runningMode:"VIDEO",numPoses:1,
        minPoseDetectionConfidence:0.65,minPosePresenceConfidence:0.65,minTrackingConfidence:0.65
      });
    });
    state.landmarker = landmarker;
    try {
      state.handLandmarker = await HandLandmarker.createFromOptions(vision, {
        baseOptions:{modelAssetPath:HAND_MODEL_URL,delegate:"GPU"},runningMode:"VIDEO",numHands:2,
        minHandDetectionConfidence:0.6,minHandPresenceConfidence:0.6,minTrackingConfidence:0.6
      }).catch(async gpuError => {
        console.warn("Hand GPU delegate failed; retrying CPU",gpuError);
        return HandLandmarker.createFromOptions(vision, {
          baseOptions:{modelAssetPath:HAND_MODEL_URL,delegate:"CPU"},runningMode:"VIDEO",numHands:2,
          minHandDetectionConfidence:0.6,minHandPresenceConfidence:0.6,minTrackingConfidence:0.6
        });
      });
    } catch(handError) {
      state.handLandmarker=null;
      console.warn("Hand Landmarker unavailable; body pose will continue",handError);
      toast("โหลด Hand Tracking ไม่สำเร็จ · ระบบติดตามโครงกระดูกหลักยังใช้งานได้", "error");
    }
    $("systemStatus").textContent = state.handLandmarker ? "BODY + HAND ENGINE READY" : "BODY POSE ENGINE READY";
    $("poseStateTag").textContent = state.handLandmarker ? "BODY + HAND ONLINE" : "BODY ONLINE · HAND OFFLINE";
    return landmarker;
  })();
  try { return await state.modelPromise; }
  catch(error) { state.modelPromise=null; $("systemStatus").textContent="MODEL ERROR"; $("poseStateTag").textContent="MODEL LOAD FAILED"; throw error; }
}
function startSession() {
  if (state.activeSession) return;
  state.activeSession = {id:crypto.randomUUID?.()||String(Date.now()),startedAt:new Date().toISOString(),endedAt:null,durationMs:0,mode:$("sessionDrill").value,hand:state.profile.hand,shots:[],phaseEvents:[],lastSnapshot:null};
  state.lastPhase="Ready";
  state.latestPose=null;state.latestAngles=null;state.latestHandMetrics=[];
  state.lastDetectAt=0;state.lastHandDetectAt=0;state.lastRenderAt=0;
  resetPoseTracking();
  $("sessionBadge").textContent="RUNNING";$("sessionBadge").classList.add("running");
  $("endSessionBtn").disabled=false;
  $("liveAttempts").textContent="0";$("liveMakes").textContent="0";$("liveFG").textContent="—%";
  state.sessionTimer=window.setInterval(updateSessionClock,1000);
  updateSessionClock();
}
function updateSessionClock() {
  if (!state.activeSession) return;
  const elapsed=Date.now()-new Date(state.activeSession.startedAt).getTime();
  $("sessionClock").textContent=fmtDuration(elapsed);
}
function discardEmptySession() {
  if (!state.activeSession || (state.activeSession.shots?.length || 0) > 0) return;
  state.activeSession=null;
  clearInterval(state.sessionTimer);state.sessionTimer=null;
  $("sessionBadge").textContent="IDLE";$("sessionBadge").classList.remove("running");
  $("endSessionBtn").disabled=true;$("sessionClock").textContent="00:00";
}
function updateSessionStats() {
  const shots=state.activeSession?.shots||[];
  const makes=shots.filter(s=>s.made).length;
  $("liveAttempts").textContent=shots.length;
  $("liveMakes").textContent=makes;
  $("liveFG").textContent=shots.length?`${Math.round(makes/shots.length*100)}%`:"—%";
}
async function recordShot(made) {
  if (!state.activeSession) { toast("เริ่มกล้องก่อนบันทึกผลชู้ต", "error"); return; }
  const snapshot=state.activeSession.lastSnapshot || (state.latestPose ? makeSnapshot(state.latestPose.image,state.latestPose.world,state.latestAngles,state.lastPhase):null);
  state.activeSession.shots.push({number:state.activeSession.shots.length+1,made,at:new Date().toISOString(),phase:state.lastPhase,snapshot});
  updateSessionStats();
  if (made) await playRandomSound();
  else toast("บันทึก MISS แล้ว", "");
}
function endSession() {
  if (!state.activeSession) return;
  const session=state.activeSession;
  session.endedAt=new Date().toISOString();
  session.durationMs=Date.now()-new Date(session.startedAt).getTime();
  session.lastSnapshot=session.lastSnapshot || null;
  state.sessions.unshift(session);
  state.sessions=state.sessions.slice(0,200);
  state.activeSession=null;
  clearInterval(state.sessionTimer);state.sessionTimer=null;
  $("sessionBadge").textContent="SAVED";$("sessionBadge").classList.remove("running");
  $("endSessionBtn").disabled=true;
  $("sessionClock").textContent="00:00";
  persist();renderDashboard();renderHistory();
  toast(`บันทึกเซสชันแล้ว · ${session.shots.length} attempts`,"success");
}
function closeSessionBeforeSourceSwitch() {
  if (!state.activeSession) return;
  if ((state.activeSession.shots?.length || 0) > 0) endSession();
  else discardEmptySession();
}
async function waitForVideoReady(video, timeoutMs = 12000) {
  const ready = () => video.readyState >= 2 && video.videoWidth > 0 && video.videoHeight > 0;
  if (ready()) return;
  await new Promise((resolve, reject) => {
    let timer;
    const events = ["loadedmetadata", "loadeddata", "canplay", "resize"];
    const cleanup = () => {
      clearTimeout(timer);
      events.forEach(name => video.removeEventListener(name, check));
      video.removeEventListener("error", fail);
    };
    const check = () => {
      if (!ready()) return;
      cleanup();
      resolve();
    };
    const fail = () => {
      cleanup();
      reject(new Error("VIDEO_LOAD_FAILED"));
    };
    events.forEach(name => video.addEventListener(name, check));
    video.addEventListener("error", fail, { once:true });
    timer = setTimeout(() => {
      cleanup();
      reject(new Error("VIDEO_READY_TIMEOUT"));
    }, timeoutMs);
    check();
  });
}
function cameraErrorMessage(error) {
  const messages = {
    NotAllowedError: "ไม่ได้รับอนุญาตให้ใช้กล้อง · เปิดสิทธิ์ Camera ให้เว็บไซต์ใน Settings ของ Browser แล้วลองใหม่",
    PermissionDeniedError: "Browser ปฏิเสธการใช้กล้อง · ตรวจสอบสิทธิ์ Camera",
    NotFoundError: "ไม่พบกล้องที่ใช้งานได้บนอุปกรณ์นี้",
    NotReadableError: "กล้องกำลังถูกใช้งานโดยแอปอื่น · ปิดแอปกล้องหรือแอปประชุมแล้วลองใหม่",
    OverconstrainedError: "กล้องไม่รองรับความละเอียดที่ร้องขอ · กำลังใช้ค่ากล้องสำรอง",
    SecurityError: "กล้องถูกบล็อก · ต้องเปิดเว็บผ่าน HTTPS หรือ localhost",
    AbortError: "การเปิดกล้องถูกยกเลิก · ลองเริ่มใหม่"
  };
  return messages[error?.name] || `เปิดกล้องไม่สำเร็จ (${error?.name || "UnknownError"}) · ตรวจสอบ HTTPS และสิทธิ์กล้อง`;
}

// Upgrade FPS in camera acquisition to 60-90
async function acquireCamera(facing = state.cameraFacing) {
  if (!navigator.mediaDevices?.getUserMedia) throw new DOMException("Camera API unavailable", "NotSupportedError");
  const base = { audio:false };
  const attempts = [
    { video:{ facingMode:{ exact:facing }, width:{ ideal:1280 }, height:{ ideal:720 }, frameRate:{ ideal:60, max:90 } }, ...base },
    { video:{ facingMode:{ ideal:facing }, width:{ ideal:1280 }, height:{ ideal:720 }, frameRate:{ ideal:60 } }, ...base },
    { video:true, ...base }
  ];
  let lastError;
  for (const constraints of attempts) {
    try { return await navigator.mediaDevices.getUserMedia(constraints); }
    catch (error) { lastError = error; if (["NotAllowedError","PermissionDeniedError","NotFoundError","NotReadableError","SecurityError"].includes(error.name)) throw error; }
  }
  throw lastError || new Error("CAMERA_UNAVAILABLE");
}

async function startCamera(facing = state.cameraFacing) {
  if (facing !== "user" && facing !== "environment") facing = state.cameraFacing === "user" ? "user" : "environment";
  if (state.videoMode === "file") { closeSessionBeforeSourceSwitch(); stopCamera(false); }
  if (!window.isSecureContext && !["localhost","127.0.0.1"].includes(location.hostname)) {
    toast("กล้องต้องเปิดผ่าน HTTPS หรือ localhost เท่านั้น", "error");
    $("cameraHint").textContent = "เปิดเว็บไซต์ผ่าน HTTPS แล้วลองอีกครั้ง";
    return;
  }
  if (!navigator.mediaDevices?.getUserMedia) {
    const message = "Safari ไม่พบ Camera API · ตรวจสอบว่าเปิดผ่าน Safari ปกติ ไม่ใช่หน้าต่าง In-App Browser และอัปเดต iPadOS";
    $("cameraHint").textContent = message;
    toast(message, "error");
    return;
  }
  try {
    $("startCameraBtn").disabled=true;
    $("cameraLabel").textContent="กำลังขอสิทธิ์กล้อง...";
    $("cameraHint").textContent="กรุณากด Allow หาก Safari ขออนุญาตใช้กล้อง";
    if (state.stream) state.stream.getTracks().forEach(track=>track.stop());
    const stream=await acquireCamera(facing);
    state.stream=stream;state.cameraFacing=facing;state.videoMode="camera";
    const video=$("cameraVideo");
    video.pause();
    video.srcObject=stream;
    video.removeAttribute("src");
    video.controls=false;
    video.muted=true;
    video.defaultMuted=true;
    video.autoplay=true;
    video.playsInline=true;
    video.setAttribute("playsinline", "");
    video.setAttribute("webkit-playsinline", "");
    video.setAttribute("autoplay", "");

    await video.play();
    await waitForVideoReady(video);

    $("cameraStage").classList.toggle("front-camera", facing === "user");
    $("cameraIndicator").classList.add("live");
    setTrackingOverlay(true);

    $("cameraLabel").textContent=`กล้อง${facing === "environment" ? "หลัง" : "หน้า"}กำลังทำงาน`;
    $("cameraHint").textContent=`กล้องเปิดแล้ว · ${video.videoWidth} × ${video.videoHeight} px · กำลังเตรียมระบบติดตาม`;
    $("stopCameraBtn").disabled=false;
    $("flipCameraBtn").disabled=false;
    $("markMakeBtn").disabled=false;
    $("markMissBtn").disabled=false;
    startSession();

    try {
      await ensureLandmarker();
      state.lastDetectAt=0;
      state.lastHandDetectAt=0;
      runPoseLoop();
      $("cameraHint").textContent=`${video.videoWidth} × ${video.videoHeight} px · ${facing === "environment" ? "Rear camera" : "Front camera"} · Tracking พร้อมใช้งาน`;
      toast("เปิดกล้องและเริ่ม Camera Tracking แล้ว", "success");
    } catch(modelError) {
      console.error("Pose model initialization failed while camera is live:", modelError);
      $("systemStatus").textContent="CAMERA READY · MODEL ERROR";
      $("poseStateTag").textContent="CAMERA ONLINE · TRACKING OFFLINE";
      $("cameraHint").textContent="กล้องเปิดแล้ว แต่โหลด AI Pose Model ไม่สำเร็จ · ตรวจสอบอินเทอร์เน็ตหรือ CDN แล้วกดเริ่มใหม่";
      toast("กล้องเปิดแล้ว แต่โหลด AI Tracking ไม่สำเร็จ · ภาพกล้องยังใช้งานได้", "error");
    }
  } catch(error) {
    console.error("Camera start failed:",error);
    $("startCameraBtn").disabled=false;
    $("cameraLabel").textContent="ไม่สามารถเริ่มกล้องได้";
    $("cameraHint").textContent=cameraErrorMessage(error);
    toast(cameraErrorMessage(error),"error");
    stopCamera(false);
    if(state.activeSession?.shots?.length) endSession(); else discardEmptySession();
  }
}
async function flipCamera() {
  if (!state.stream) { state.cameraFacing=state.cameraFacing === "environment" ? "user" : "environment"; toast(`เลือกกล้อง${state.cameraFacing === "environment" ? "หลัง" : "หน้า"}ไว้แล้ว`); return; }
  const next=state.cameraFacing === "environment" ? "user" : "environment";
  const hadSession=!!state.activeSession;
  if (hadSession) { if(state.activeSession.shots.length) endSession(); else discardEmptySession(); }
  stopCamera(false);
  await startCamera(next);
}
async function loadVideoFile(file) {
  if (!file) return;
  closeSessionBeforeSourceSwitch();
  stopCamera(false);
  if (state.videoObjectUrl) URL.revokeObjectURL(state.videoObjectUrl);
  state.videoObjectUrl=URL.createObjectURL(file);
  state.videoMode="file";
  const video=$("cameraVideo");video.srcObject=null;video.src=state.videoObjectUrl;video.controls=true;video.muted=true;
  try {
    await video.play();
    $("cameraIndicator").classList.add("live");
    $("cameraLabel").textContent=`วิดีโอ: ${file.name}`;
    $("stopCameraBtn").disabled=false;$("markMakeBtn").disabled=false;$("markMissBtn").disabled=false;
    setTrackingOverlay(true);

    startSession();await ensureLandmarker();runPoseLoop();
    toast("เริ่มวิเคราะห์วิดีโอแล้ว","success");
  } catch(error) { console.error(error);toast("เปิดวิดีโอไม่สำเร็จ หรือโหลด Pose Model ไม่สำเร็จ","error");stopCamera(false);if(state.activeSession?.shots?.length)endSession();else discardEmptySession(); }
}
function stopCamera(end = true) {
  cancelPoseLoop();
  if (state.stream) state.stream.getTracks().forEach(track=>track.stop());
  state.stream=null;
  const video=$("cameraVideo");
  if (video.srcObject) video.srcObject=null;
  if (state.videoMode==="file") {
    video.pause();
    video.removeAttribute("src");
    video.load();
    if (state.videoObjectUrl) { URL.revokeObjectURL(state.videoObjectUrl); state.videoObjectUrl=null; }
    video.controls=false;
  }
  state.videoMode="camera";
  $("cameraStage").classList.remove("front-camera");
  $("cameraIndicator").classList.remove("live");
  setTrackingOverlay(false);
  
  $("cameraLabel").textContent="กล้องยังไม่เริ่มทำงาน";
  $("startCameraBtn").disabled=false;$("stopCameraBtn").disabled=true;$("flipCameraBtn").disabled=true;$("markMakeBtn").disabled=true;$("markMissBtn").disabled=true;
  $("fpsCounter").textContent="0 FPS";$("confidenceLabel").textContent="CONFIDENCE: —";
  const canvas=$("poseCanvas");canvas.getContext("2d").clearRect(0,0,canvas.width,canvas.height);
  state.latestHandMetrics=[];
  updateHandAngleTable();
  if (end && state.activeSession) endSession();
}

function detectFrame(video, now) {
  state.lastDetectAt=now;
  try {
    const results=state.landmarker.detectForVideo(video,now);
    if(state.handLandmarker && now-state.lastHandDetectAt>250){
      state.lastHandDetectAt=now;
      try { const handResults=state.handLandmarker.detectForVideo(video,now);state.latestHandMetrics=buildHandMetrics(handResults); }
      catch(handError){state.latestHandMetrics=[];console.warn("Hand tracking frame failed",handError);}
    }
    const rawImage=results.landmarks?.[0];
    const rawWorld=results.worldLandmarks?.[0];
    if (rawImage && rawWorld) {
      // One-Euro filter on landmarks: removes jitter while keeping fast shooting motion responsive
      const image=filterLandmarks(rawImage,"image",now);
      const world=filterLandmarks(rawWorld,"world",now);
      const measures=buildMeasurements(image,world,state.angleMode);
      const phase=currentPhase(image,measures);
      if (phase!==state.lastPhase) {
        state.activeSession?.phaseEvents.push({phase,at:new Date().toISOString()});
        state.lastPhase=phase;
      }
      state.latestPose={image,world,timestamp:now,phase};state.latestAngles=measures;
      state.poseHistory.push({t:now,v:currentHandMeasurements(measures),q:qualityScore(image)});
      while(state.poseHistory.length && now-state.poseHistory[0].t>1500) state.poseHistory.shift();
      if (state.activeSession) state.activeSession.lastSnapshot=makeSnapshot(image,world,measures,phase);
      drawPose(image,state.latestHandMetrics);
      if (now - state.lastRenderAt > 200) { // Limit DOM updates to 5 FPS to stop freezing menus
        updatePoseUI(image,world,measures,phase);
        state.lastRenderAt = now;
      }
    } else {
      const ctx=$("poseCanvas").getContext("2d");ctx.clearRect(0,0,$("poseCanvas").width,$("poseCanvas").height);
      if(now-state.lastRenderAt>900){$("liveFeedback").innerHTML='<div class="feedback-empty">ไม่พบผู้เล่นในกรอบภาพ ลองปรับตำแหน่งกล้อง</div>';state.lastRenderAt=now;}
    }
    state.fpsFrames++;
    if(now-state.fpsStart>=1000){state.fps=Math.round(state.fpsFrames*1000/(now-state.fpsStart));state.fpsFrames=0;state.fpsStart=now;$("fpsCounter").textContent=`${state.fps} FPS`;}
  } catch(error) { console.error("Pose inference error",error); }
}
function runPoseLoop() {
  const video=$("cameraVideo");
  cancelPoseLoop();
  const token=state.loopToken;
  // requestVideoFrameCallback fires once per real camera frame (60-90 FPS capable, no duplicate frames)
  const useVFC=typeof video.requestVideoFrameCallback==="function";
  if (state.videoMode==="file") video.addEventListener("ended",()=>{ if(token===state.loopToken) stopCamera(true); },{once:true});
  const schedule=()=>{
    if (token!==state.loopToken) return;
    if (useVFC) state.videoFrameHandle=video.requestVideoFrameCallback(loop);
    else state.animationFrame=requestAnimationFrame(loop);
  };
  const loop=(now)=>{
    if (token!==state.loopToken) return;
    if (state.videoMode === "file" && video.ended) { stopCamera(true); return; }
    if (!state.landmarker || video.readyState<2 || video.paused || video.ended) { schedule(); return; }
    if (!useVFC && video.currentTime===state.lastVideoTime) { schedule(); return; }
    state.lastVideoTime=video.currentTime;
    detectFrame(video,now);
    schedule();
  };
  schedule();
}

function renderDashboard() {
  const totals=getSessionTotals();
  $("statSessions").textContent=state.sessions.length;
  $("statAttempts").textContent=totals.attempts;
  $("statAccuracy").innerHTML=totals.accuracy==null?"—<small>%</small>":`${Math.round(totals.accuracy)}<small>%</small>`;
  $("statMakes").textContent=totals.makes;
  const recent=state.sessions.slice(0,7).reverse();
  const chart=$("accuracyChart");
  if(!recent.length){chart.innerHTML='<div class="empty-chart">เริ่มบันทึกการฝึกเพื่อดูกราฟพัฒนาการ</div>';}
  else {
    const values=recent.map(s=>s.shots?.length?((s.shots.filter(x=>x.made).length/s.shots.length)*100):0);
    const width=600,height=145,pad=16;
    const points=values.map((v,i)=>({x:pad+(values.length===1?(width-pad*2)/2:i*(width-pad*2)/(values.length-1)),y:height-pad-(v/100)*(height-pad*2)}));
    const poly=points.map(p=>`${p.x},${p.y}`).join(" ");
    const area=`${points[0].x},${height-pad} ${poly} ${points.at(-1).x},${height-pad}`;
    chart.innerHTML=`<svg viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" role="img" aria-label="Accuracy trend"><defs><linearGradient id="chartFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#91cfff" stop-opacity=".22"/><stop offset="100%" stop-color="#91cfff" stop-opacity="0"/></linearGradient></defs>${[25,50,75].map(v=>`<line x1="${pad}" y1="${height-pad-(v/100)*(height-pad*2)}" x2="${width-pad}" y2="${height-pad-(v/100)*(height-pad*2)}" stroke="#263442" stroke-dasharray="3 5"/><text x="0" y="${height-pad-(v/100)*(height-pad*2)+3}" fill="#667889" font-size="8">${v}</text>`).join("")}<polygon points="${area}" fill="url(#chartFill)"/><polyline points="${poly}" fill="none" stroke="#91cfff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>${points.map((p,i)=>`<circle cx="${p.x}" cy="${p.y}" r="3.5" fill="#101820" stroke="#a9dcff" stroke-width="2"><title>${values[i].toFixed(0)}%</title></circle>`).join("")}</svg>`;
  }
  const rows=state.sessions.slice(0,4);
  $("dashboardRecent").innerHTML=rows.length?`<div class="table-scroll"><table class="data-table"><thead><tr><th>DATE / TIME</th><th>MODE</th><th>ATTEMPTS</th><th>MAKES</th><th>FG%</th></tr></thead><tbody>${rows.map(s=>{const a=s.shots?.length||0,m=(s.shots||[]).filter(x=>x.made).length;return `<tr><td>${escapeHTML(fmtDate(s.startedAt))}</td><td>${escapeHTML(s.mode)}</td><td>${a}</td><td>${m}</td><td>${a?Math.round(m/a*100):"—"}%</td></tr>`}).join("")}</tbody></table></div>`:'<div class="empty-state compact-empty">ยังไม่มีประวัติการฝึก เริ่มต้นเซสชันแรกของคุณได้เลย</div>';
}
function renderHistory() {
  const totals=getSessionTotals();
  $("historySessions").textContent=state.sessions.length;$("historyShots").textContent=totals.attempts;$("historyMakes").textContent=totals.makes;$("historyAccuracy").innerHTML=totals.accuracy==null?"—<small>%</small>":`${Math.round(totals.accuracy)}<small>%</small>`;
  const table=$("historyTable");
  if(!state.sessions.length){table.innerHTML='<tr><td colspan="7" class="table-empty">ยังไม่มีประวัติการฝึก</td></tr>';return;}
  table.innerHTML=state.sessions.map((s,i)=>{const a=s.shots?.length||0,m=(s.shots||[]).filter(x=>x.made).length;return `<tr><td>${escapeHTML(fmtDate(s.startedAt))}</td><td>${escapeHTML(s.mode)}</td><td>${a}</td><td>${m}</td><td>${a?Math.round(m/a*100):"—"}%</td><td>${fmtDuration(s.durationMs||0)}</td><td><button class="table-action" data-session-view="${escapeHTML(s.id)}">ดู</button><button class="table-action delete" data-session-delete="${escapeHTML(s.id)}">ลบ</button></td></tr>`}).join("");
}
function viewSession(id) {
  const s=state.sessions.find(x=>x.id===id);if(!s)return;
  const attempts=s.shots?.length||0,makes=(s.shots||[]).filter(x=>x.made).length;
  const shotDetails=(s.shots||[]).map((shot,i)=>{
    const angles=shot.snapshot?.angles||{};
    const angleRows=Object.entries(angles).filter(([key,value])=>typeof value==="number"&&Number.isFinite(value)).map(([key,value])=>`<tr><td>${escapeHTML(key)}</td><td>${round(value,2)}°</td></tr>`).join("");
    return `<details class="shot-detail"><summary>Shot ${i+1} · ${shot.made?"MAKE":"MISS"} · ${escapeHTML(shot.phase||"—")}</summary><p>Pose quality: ${shot.snapshot?.quality??"—"}% · Landmarks: ${shot.snapshot?.landmarks?.length??0} · Hands: ${shot.snapshot?.hands?.length??0}</p><div class="table-scroll"><table class="data-table"><thead><tr><th>MEASUREMENT</th><th>VALUE</th></tr></thead><tbody>${angleRows||'<tr><td colspan="2">ไม่มี snapshot มุมในช็อตนี้</td></tr>'}</tbody></table></div></details>`;
  }).join("");
  const body=`<p><b>${escapeHTML(s.mode)}</b> · ${escapeHTML(fmtDate(s.startedAt))}</p><p>Attempts: <b>${attempts}</b> · Makes: <b>${makes}</b> · FG%: <b>${attempts?Math.round(makes/attempts*100):0}%</b></p><p>Duration: ${fmtDuration(s.durationMs||0)} · Shooting hand: ${escapeHTML(s.hand||"—")}</p><h4>SHOT-BY-SHOT BIOMECHANICS</h4>${shotDetails||'<p>ไม่มีช็อตที่บันทึกไว้</p>'}`;
  showModal("Session detail",body,[{label:"Export session JSON",className:"primary-button",onClick:()=>downloadJSON(s,`ballform-session-${s.id}.json`)},{label:"ปิด",className:"outline-button"}],"◷");
}
function deleteSession(id) {
  showModal("ลบเซสชันนี้?","<p>ข้อมูลของเซสชันนี้จะถูกลบออกจาก Browser นี้อย่างถาวร</p>",[{label:"ยืนยันลบ",className:"primary-button",onClick:()=>{state.sessions=state.sessions.filter(s=>s.id!==id);persist();renderHistory();renderDashboard();toast("ลบเซสชันแล้ว","success")}},{label:"ยกเลิก",className:"outline-button"}],"!");
}
function downloadJSON(data,filename) {
  const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"});
  const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=filename;a.click();URL.revokeObjectURL(url);
}
function exportAll() { downloadJSON({app:"BallForm AI",version:APP_VERSION,exportedAt:new Date().toISOString(),profile:state.profile,settings:state.settings,sessions:state.sessions},"ballform-ai-export.json"); }
function exportCSV() {
  const rows=[["session_id","date","mode","shot_number","made","phase","elbow_left_deg","elbow_right_deg","shoulder_left_deg","shoulder_right_deg","knee_left_deg","knee_right_deg","trunk_lean_deg"]];
  state.sessions.forEach(s=>(s.shots||[]).forEach(shot=>{const a=shot.snapshot?.angles||{};rows.push([s.id,s.startedAt,s.mode,shot.number,shot.made,shot.phase,a.elbowLeft??"",a.elbowRight??"",a.shoulderLeft??"",a.shoulderRight??"",a.kneeLeft??"",a.kneeRight??"",a.trunkLean??""]);}));
  const csv=rows.map(r=>r.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(",")).join("\r\n");
  const blob=new Blob(["\uFEFF"+csv],{type:"text/csv;charset=utf-8"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download="ballform-shot-data.csv";a.click();URL.revokeObjectURL(url);
}
function renderDrills(filter=state.drillFilter) {
  state.drillFilter=filter;
  $("drillGrid").innerHTML=DRILLS.filter(d=>filter==="All"||d.category===filter).map(d=>`<article class="drill-card"><div class="drill-meta"><span class="drill-category">${escapeHTML(d.category)}</span><span class="drill-time">${escapeHTML(d.time)}</span></div><h3>${escapeHTML(d.title)}</h3><p>${escapeHTML(d.desc)}</p><div class="drill-points">${d.points.map(p=>`<span>${escapeHTML(p)}</span>`).join("")}</div><button class="outline-button" data-drill-start="${d.id}">เริ่มแบบฝึก ↗</button></article>`).join("");
}
function renderPlayers() {
  const search=state.nbaSearch.toLowerCase();
  const list=NBA_PLAYERS.filter(p=>(state.nbaEra==="All"||p.era===state.nbaEra)&&(state.nbaStyle==="All"||p.style===state.nbaStyle)&&(!search||p.name.toLowerCase().includes(search)||p.label.toLowerCase().includes(search)||p.tags.join(" ").includes(search)));
  $("nbaCount").textContent=`${list.length} PLAYERS`;
  $("playerGrid").innerHTML=list.map(p=>`<article class="player-card"><div class="player-card-top"><span class="player-initial">${escapeHTML(p.name.split(" ").map(x=>x[0]).slice(0,2).join(""))}</span><span class="player-era">${escapeHTML(p.era)}</span></div><h3>${escapeHTML(p.name)}</h3><small>${escapeHTML(p.label)}</small><div class="player-style">${escapeHTML(STYLE_ARCHETYPES[p.style].label)}</div><div class="player-tags">${p.tags.map(t=>`<span>${escapeHTML(t)}</span>`).join("")}</div></article>`).join("")||'<div class="empty-state">ไม่พบผู้เล่นที่ตรงกับคำค้นหา</div>';
}

function median(values) {
  const v = values.filter(Number.isFinite).sort((x,y)=>x-y);
  if (!v.length) return null;
  const m = Math.floor(v.length/2);
  return v.length % 2 ? v[m] : (v[m-1]+v[m])/2;
}
function validateBodyForComparison() {
  const pose = state.latestPose;
  if (!pose?.image || !state.latestAngles) return { ok:false, msg:"ระบบยังไม่สามารถตรวจจับการเคลื่อนไหวได้ กรุณาขยับเข้ามาในกล้อง" };
  const live = !!(state.stream || state.videoMode === "file");
  if (!live || performance.now() - pose.timestamp > 1000) return { ok:false, msg:"ไม่มีข้อมูล Motion Capture สด · กรุณาเริ่มกล้องและให้ระบบติดตามร่างกายก่อน" };
  const quality = qualityScore(pose.image);
  if (!(quality >= 75)) return { ok:false, msg:`เห็นร่างกายไม่ครบถ้วน (${quality ?? 0}%) กรุณาถอยให้กล้องเห็นตั้งแต่ศีรษะถึงเท้าก่อนทำการวิเคราะห์เทียบผู้เล่น NBA` };
  const chain = state.profile.hand === "left" ? [0,11,13,15,23,25,27] : [0,12,14,16,24,26,28];
  const minVis = Math.max(state.settings.threshold, 0.6);
  const weak = chain.filter(i => (pose.image[i]?.visibility ?? 0) < minVis);
  if (weak.length) return { ok:false, msg:"จุดข้อต่อฝั่งแขนที่ใช้ยิงยังเห็นไม่ชัดพอ (ไหล่–ศอก–ข้อมือ–สะโพก–เข่า–ข้อเท้า) กรุณาหันด้านข้างเล็กน้อยและอย่าให้ถูกบัง" };
  const outside = chain.filter(i => { const p = pose.image[i]; return !p || p.x < -0.01 || p.x > 1.01 || p.y < -0.01 || p.y > 1.01; });
  if (outside.length) return { ok:false, msg:"ร่างกายบางส่วนอยู่นอกกรอบภาพ กรุณาถอยหรือขยับให้เห็นทั้งตัว" };
  const recent = state.poseHistory.filter(h => pose.timestamp - h.t <= 1000 && (h.q ?? 0) >= 75);
  if (recent.length < 8) return { ok:false, msg:"ระบบยังเก็บข้อมูลท่าทางไม่พอ · กรุณายืนอยู่ในกรอบให้ครบทั้งตัวประมาณ 1 วินาทีแล้วลองใหม่" };
  const hand = {};
  ["elbow","shoulder","knee","hip","trunkLean","wrist"].forEach(k => { hand[k] = median(recent.map(h => h.v?.[k])); });
  if (!Number.isFinite(hand.elbow)) return { ok:false, msg:"ระบบไม่สามารถตรวจจับองศาข้อศอกได้ชัดเจน กรุณาหันด้านข้างเล็กน้อยแล้วลองใหม่" };
  const missing = ["shoulder","knee","hip"].filter(k => !Number.isFinite(hand[k]));
  if (missing.length) return { ok:false, msg:`ระบบยังวัดองศา ${missing.join(", ")} ไม่ได้ครบ กรุณาปรับตำแหน่งกล้องให้เห็นทั้งตัวแล้วลองใหม่` };
  return { ok:true, hand, quality, frames:recent.length };
}

function compareStyle() {
  // Verify the body is fully tracked and stable BEFORE showing any NBA style match
  const check = validateBodyForComparison();
  if (!check.ok) { toast(check.msg, "error"); return; }
  const hand = check.hand;
  const weights={elbow:1.1,shoulder:1,knee:.8,hip:.6,trunkLean:.8,wrist:.5};
  const maxDiff={elbow:70,shoulder:90,knee:60,hip:60,trunkLean:25,wrist:80};
  const ranked=Object.entries(STYLE_ARCHETYPES).map(([key,archetype])=>{
    let weighted=0,total=0;
    Object.entries(weights).forEach(([metric,weight])=>{
      const value=hand[metric],target=archetype.target[metric];
      if(Number.isFinite(value)&&Number.isFinite(target)){weighted+=Math.abs(value-target)/maxDiff[metric]*weight;total+=weight;}
    });
    const score=total?Math.round(clamp(100-(weighted/total)*100,0,100)):0;
    return {key,score,label:archetype.label,description:archetype.description};
  }).sort((a,b)=>b.score-a.score);
  
  const cards=ranked.slice(0,3).map((item,i)=>{
    const players=NBA_PLAYERS.filter(p=>p.style===item.key).slice(0,3);
    return `<div class="comparison-card"><div class="comparison-rank">MATCH ${String(i+1).padStart(2,"0")}</div><h4>${escapeHTML(item.label)}</h4><small>${escapeHTML(item.description)}</small><div class="similarity-bar"><i style="width:${item.score}%"></i></div><div class="similarity-value">${item.score}% · heuristic similarity</div><small style="margin-top:8px;display:block">ตัวอย่าง: ${players.map(p=>escapeHTML(p.name)).join(", ")}</small></div>`;
  }).join("");
  
  $("comparisonResults").innerHTML=`<small style="display:block;margin-bottom:8px">ตรวจสอบร่างกายผ่านแล้ว · ความครบของ landmark ${check.quality}% · ใช้ค่ากลางจาก ${check.frames} เฟรมล่าสุด</small><div class="comparison-cards">${cards}</div>`;
  toast("ตรวจจับร่างกายสมบูรณ์แบบ! วิเคราะห์สไตล์การชู้ตเสร็จสิ้น","success");
}

function renderSounds() {
  const grid=$("soundGrid");
  grid.innerHTML=Array.from({length:50},(_,i)=>i+1).map(n=>`<div class="sound-item ${state.soundFiles.has(n)?"ready":""}" data-sound-item="${n}"><span class="sound-number">${String(n).padStart(2,"0")}</span><div><b>sounds${n}.mp3</b><small class="sound-status">${state.soundFiles.has(n)?"READY":"CHECK FILE"}</small></div><button title="ทดลองเสียง" data-sound-play="${n}">▶</button></div>`).join("");
  $("soundReadyCount").textContent=`${state.soundFiles.size} / 50 READY`;
  $("soundEnabled").checked=!!state.settings.soundEnabled;
  $("soundVolume").value=Math.round(state.settings.soundVolume*100);
  $("soundVolumeValue").textContent=`${Math.round(state.settings.soundVolume*100)}%`;
  probeSoundFiles();
}
async function probeSoundFiles() {
  const available=new Set();
  const checks=Array.from({length:50},(_,i)=>i+1).map(async n=>{
    try { const response=await fetch(`sounds/sounds${n}.mp3`,{method:"HEAD",cache:"no-store"});if(response.ok)available.add(n); } catch {}
  });
  await Promise.all(checks);
  state.soundFiles=available;
  document.querySelectorAll("[data-sound-item]").forEach(card=>{
    const n=Number(card.dataset.soundItem);card.classList.toggle("ready",available.has(n));
    const label=card.querySelector(".sound-status");if(label)label.textContent=available.has(n)?"READY":"NOT FOUND";
  });
  $("soundReadyCount").textContent=`${available.size} / 50 READY`;
}
function getRandomSoundNumber() {
  const pool=state.soundFiles.size?[...state.soundFiles]:Array.from({length:50},(_,i)=>i+1);
  if(pool.length>1&&state.lastSoundNumber!=null){const idx=pool.indexOf(state.lastSoundNumber);if(idx>=0)pool.splice(idx,1);}
  const n=pool[Math.floor(Math.random()*pool.length)];state.lastSoundNumber=n;return n;
}
async function playSoundNumber(n) {
  if(state.soundAudio){state.soundAudio.pause();state.soundAudio.currentTime=0;}
  const audio=new Audio(`sounds/sounds${n}.mp3`);audio.volume=state.settings.soundVolume;audio.preload="auto";state.soundAudio=audio;
  try {
    await audio.play();
    $("lastSound").textContent=`กำลังเล่น sounds${n}.mp3`;
    audio.addEventListener("ended",()=>{if(state.soundAudio===audio)$("lastSound").textContent=`เล่นล่าสุด: sounds${n}.mp3`;},{once:true});
    return true;
  } catch(error) {
    console.warn(`Cannot play sounds${n}.mp3`,error);
    $("lastSound").textContent=`ไม่พบหรือเล่น sounds${n}.mp3 ไม่ได้`;
    toast(`เล่น sounds${n}.mp3 ไม่ได้ · ตรวจสอบไฟล์ใน /sounds/`,"error");
    return false;
  }
}
async function playRandomSound() {
  if(!state.settings.soundEnabled)return;
  if(state.soundFiles.size===0){
    if(!state.soundMissingWarned){toast("ยังไม่พบไฟล์เสียงใน /sounds/ · เพิ่ม sounds1.mp3 ถึง sounds50.mp3 ก่อนใช้งาน", "error");state.soundMissingWarned=true;}
    $("lastSound").textContent="ยังไม่พบไฟล์เสียงใน /sounds/";
    return;
  }
  const n=getRandomSoundNumber();
  await playSoundNumber(n);
}
function stopSound() { if(state.soundAudio){state.soundAudio.pause();state.soundAudio.currentTime=0;}$("lastSound").textContent="หยุดเสียงแล้ว"; }

function populateSettings() {
  $("playerName").value=state.profile.name||"";$("profileHand").value=state.profile.hand||"right";$("profileHeight").value=state.profile.height||"";
  $("trackingQuality").value=state.settings.quality;$("confidenceThreshold").value=Math.round(state.settings.threshold*100);$("confidenceValue").textContent=`${Math.round(state.settings.threshold*100)}%`;
  $("showSkeleton").checked=!!state.settings.skeleton;$("showLabels").checked=!!state.settings.labels;
}
function saveProfile() {
  const height=Number($("profileHeight").value);
  if($("profileHeight").value && (!Number.isFinite(height)||height<100||height>240)){toast("ส่วนสูงควรอยู่ระหว่าง 100–240 ซม.","error");return;}
  state.profile={name:$("playerName").value.trim()||"Player",hand:$("profileHand").value,height:$("profileHeight").value||""};
  $("cameraSide").value=state.profile.hand;
  persist();updatePlayerName();toast("บันทึกโปรไฟล์แล้ว","success");
}
function updatePlayerName(){const name=state.profile.name||"Player";$("topPlayerName").textContent=name;$("avatarInitial").textContent=name.trim()[0]?.toUpperCase()||"P";}
function resetApp() {
  showModal("รีเซ็ตข้อมูลทั้งหมด?","<p>ระบบจะลบโปรไฟล์ การตั้งค่า และประวัติการฝึกทั้งหมดจาก Browser นี้ ไม่สามารถย้อนกลับได้</p>",[{label:"รีเซ็ตทั้งหมด",className:"primary-button",onClick:()=>{state.profile={name:"Player",hand:"right",height:""};state.settings={quality:"lite",threshold:.5,skeleton:true,labels:false,soundEnabled:true,soundVolume:.75,angleMode:"3d"};state.sessions=[];persist();updatePlayerName();populateSettings();renderDashboard();renderHistory();toast("รีเซ็ตข้อมูลเรียบร้อย","success")}},{label:"ยกเลิก",className:"outline-button"}],"!");
}

function bindEvents() {
  document.querySelectorAll("[data-view]").forEach(button=>button.addEventListener("click",()=>setView(button.dataset.view)));
  $("mobileMenu").addEventListener("click",()=>$("sidebar").classList.toggle("open"));
  $("startCameraBtn").addEventListener("click",()=>startCamera());
  $("stopCameraBtn").addEventListener("click",()=>stopCamera(true));
  $("flipCameraBtn").addEventListener("click",flipCamera);
  $("uploadVideoBtn").addEventListener("click",()=>$("videoFileInput").click());
  $("videoFileInput").addEventListener("change",e=>loadVideoFile(e.target.files?.[0]));
  $("markMakeBtn").addEventListener("click",()=>recordShot(true));
  $("markMissBtn").addEventListener("click",()=>recordShot(false));
  $("endSessionBtn").addEventListener("click",()=>{stopCamera(false);if(state.activeSession)endSession();});
  $("sessionDrill").addEventListener("change",()=>{if(state.activeSession){state.activeSession.mode=$("sessionDrill").value;}});
  $("cameraSide").addEventListener("change",e=>{state.profile.hand=e.target.value;$("profileHand").value=e.target.value;persist();});
  $("showAllAnglesBtn").addEventListener("click",()=>{state.allAnglesVisible=!state.allAnglesVisible;$("liveAngleTableWrap").hidden=!state.allAnglesVisible;$("showAllAnglesBtn").textContent=state.allAnglesVisible?"ซ่อนรายละเอียด ↑":"ดูทั้งหมด ↓";});
  document.querySelectorAll("[data-angle-mode]").forEach(button=>button.addEventListener("click",()=>{
    state.angleMode=button.dataset.angleMode;state.settings.angleMode=state.angleMode;
    document.querySelectorAll("[data-angle-mode]").forEach(b=>b.classList.toggle("active",b===button));
    $("angleModeTag").textContent=state.angleMode.toUpperCase()+ (state.angleMode==="3d"?" WORLD":" IMAGE");
    if(state.latestPose){state.latestAngles=buildMeasurements(state.latestPose.image,state.latestPose.world,state.angleMode);updatePoseUI(state.latestPose.image,state.latestPose.world,state.latestAngles,state.latestPose.phase);}
    persist();
  }));
  $("runStyleCompare").addEventListener("click",compareStyle);
  $("drillFilters").addEventListener("click",e=>{const b=e.target.closest("[data-filter]");if(!b)return;document.querySelectorAll("[data-filter]").forEach(x=>x.classList.toggle("active",x===b));renderDrills(b.dataset.filter);});
  $("drillGrid").addEventListener("click",e=>{const b=e.target.closest("[data-drill-start]");if(!b)return;const drill=DRILLS.find(d=>d.id===b.dataset.drillStart);if(!drill)return;$("sessionDrill").value=drill.mode;setView("studio");toast(`เลือกแบบฝึก ${drill.title} แล้ว`,"success");});
  $("nbaSearch").addEventListener("input",e=>{state.nbaSearch=e.target.value;renderPlayers();});
  $("nbaEraFilter").addEventListener("change",e=>{state.nbaEra=e.target.value;renderPlayers();});
  $("nbaStyleFilter").addEventListener("change",e=>{state.nbaStyle=e.target.value;renderPlayers();});
  $("historyTable").addEventListener("click",e=>{const view=e.target.closest("[data-session-view]");const del=e.target.closest("[data-session-delete]");if(view)viewSession(view.dataset.sessionView);if(del)deleteSession(del.dataset.sessionDelete);});
  $("exportAllBtn").addEventListener("click",exportAll);$("exportDataBtn").addEventListener("click",exportAll);$("exportCSVBtn").addEventListener("click",exportCSV);
  $("clearHistoryBtn").addEventListener("click",()=>showModal("ลบประวัติการฝึกทั้งหมด?","<p>โปรไฟล์และการตั้งค่าจะไม่ถูกลบ แต่เซสชันที่บันทึกไว้ทั้งหมดจะหายไป</p>",[{label:"ลบประวัติ",className:"primary-button",onClick:()=>{state.sessions=[];persist();renderHistory();renderDashboard();toast("ลบประวัติทั้งหมดแล้ว","success")}},{label:"ยกเลิก",className:"outline-button"}],"!") );
  $("saveProfileBtn").addEventListener("click",saveProfile);
  $("trackingQuality").addEventListener("change",e=>{state.settings.quality=e.target.value;persist();toast("บันทึกคุณภาพโมเดลแล้ว จะมีผลเมื่อเริ่มกล้องครั้งถัดไป");});
  $("confidenceThreshold").addEventListener("input",e=>{state.settings.threshold=Number(e.target.value)/100;$("confidenceValue").textContent=`${e.target.value}%`;persist();if(state.latestPose)drawPose(state.latestPose.image);});
  $("showSkeleton").addEventListener("change",e=>{state.settings.skeleton=e.target.checked;persist();if(state.latestPose)drawPose(state.latestPose.image);});
  $("showLabels").addEventListener("change",e=>{state.settings.labels=e.target.checked;persist();if(state.latestPose)drawPose(state.latestPose.image);});
  $("soundEnabled").addEventListener("change",e=>{state.settings.soundEnabled=e.target.checked;persist();});
  $("soundVolume").addEventListener("input",e=>{state.settings.soundVolume=Number(e.target.value)/100;$("soundVolumeValue").textContent=`${e.target.value}%`;if(state.soundAudio)state.soundAudio.volume=state.settings.soundVolume;persist();});
  $("testRandomSound").addEventListener("click",()=>playRandomSound());$("stopSound").addEventListener("click",stopSound);
  $("soundGrid").addEventListener("click",e=>{const b=e.target.closest("[data-sound-play]");if(b)playSoundNumber(Number(b.dataset.soundPlay));});
  $("resetAppBtn").addEventListener("click",resetApp);
  $("modalClose").addEventListener("click",closeModal);$("modalBackdrop").addEventListener("click",e=>{if(e.target===$("modalBackdrop"))closeModal();});
  window.addEventListener("beforeunload",()=>{if(state.stream)state.stream.getTracks().forEach(t=>t.stop());if(state.animationFrame)cancelAnimationFrame(state.animationFrame);if(state.landmarker)state.landmarker.close();if(state.handLandmarker)state.handLandmarker.close();});
}


function injectCSSFix() {
  if (document.getElementById('ballform-click-fix')) return;
  const style = document.createElement('style');
  style.id = 'ballform-click-fix';
  style.innerHTML = `
    /* Prevent camera stage from capturing clicks meant for menus */
    #cameraStage { pointer-events: none !important; }
    #cameraStage * { pointer-events: none !important; }
    /* Ensure controls inside camera stay clickable */
    .camera-controls, .camera-controls * { pointer-events: auto !important; }
    /* Ensure menus and navigation have highest priority and are clickable */
    #sidebar, .sidebar, header, .nav-item, nav, .menu { pointer-events: auto !important; z-index: 99999 !important; }
    button, a, input, select { pointer-events: auto !important; }
    #cameraVideo[controls] { pointer-events: auto !important; }
    /* Tracking active: remove start window so the camera feed is fully visible */
    #cameraStage.tracking-active .camera-overlay, #cameraStage.tracking-active #cameraPlaceholder, #cameraStage.tracking-active #startCameraBtn { display: none !important; visibility: hidden !important; }
    #cameraStage.tracking-active #cameraVideo { opacity: 1 !important; filter: none !important; visibility: visible !important; }
  `;
  document.head.appendChild(style);
}

function init() {
  injectCSSFix();
  updatePlayerName();populateSettings();bindEvents();renderDashboard();renderHistory();renderDrills();renderPlayers();
  $("cameraSide").value=state.profile.hand||"right";
  document.querySelectorAll("[data-angle-mode]").forEach(button=>button.classList.toggle("active",button.dataset.angleMode===state.angleMode));
  $("angleModeTag").textContent=state.angleMode.toUpperCase()+(state.angleMode==="3d"?" WORLD":" IMAGE");
  $("systemStatus").textContent="SYSTEM READY";
  void probeSoundFiles();
  if(!window.isSecureContext && location.hostname!=="localhost" && location.hostname!=="127.0.0.1") {
    $("cameraHint").textContent="กล้องต้องใช้งานบน HTTPS หรือ localhost";
  }
}

init();
